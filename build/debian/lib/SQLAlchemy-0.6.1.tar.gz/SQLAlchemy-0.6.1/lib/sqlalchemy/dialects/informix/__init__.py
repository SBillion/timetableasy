from sqlalchemy.dialects.informix import base, informixdb

base.dialect = informixdb.dialect