"""
Working examples of single-table, joined-table, and concrete-table inheritance as described in :ref:`datamapping_inheritance`.

"""